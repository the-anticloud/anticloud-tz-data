# Competitive Moat — TZ_DATA

## Why Anticloud Wins in CARBON_CAPTURE

1. **PAX L5 Narrow L2 General 27B runs offline** — no competitor offers a 27B-parameter model that runs fully air-gapped at this quality level
2. **AIOSS ledger is cryptographically tamper-evident** — cloud providers cannot offer this because they control the audit log
3. **Single binary** — no Docker, no Kubernetes, no cloud account required. Deployable by anyone.
4. **Zero telemetry** — verified by network monitor. Cloud competitors cannot make this claim.
5. **Apache 2.0 upstream + Anticommons additions** — full source transparency

## Upstream: https://github.com/transitionzero/tz-data

The upstream project provides the domain foundation. Anticloud adds the AI layer, security layer, and deployment layer that no cloud-dependent fork can match.

## Moat Summary

Regulated industries (government, medical, defense, finance) cannot use cloud AI. Anticloud is the only production-ready option. That is the moat.
