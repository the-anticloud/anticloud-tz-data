# 29 Investor Memo

**Project:** TZ_DATA
**Upstream:** https://github.com/transitionzero/tz-data

Content specific to TZ_DATA in category CARBON_CAPTURE.
